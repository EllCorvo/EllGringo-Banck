document.addEventListener('DOMContentLoaded', function () {
    // Elementos principais
    const bankMainScreen = document.getElementById('bank-main-screen');
    const closeBtn = document.getElementById('close-btn');
    const modal = document.getElementById('confirmation-modal');
    
    // Dados do usuário
    let userData = null;
    let currentScreen = 'dashboard';
    
    // Taxa de juros para empréstimos (5% ao mês)
    const INTEREST_RATE = 0.05;
    
    // Função para postar mensagens para o Lua
    const post = (event, data = {}) => {
        fetch(`https://${GetParentResourceName()}/${event}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify(data),
        }).catch(err => console.error(`[Bank] Fetch error: ${err}`));
    };

    // Formata o dinheiro para o padrão brasileiro
    const formatMoney = (amount) => {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(amount || 0);
    };

    // Formata data para o padrão brasileiro
    const formatDate = (date) => {
        return new Intl.DateTimeFormat('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(new Date(date));
    };

    // Calcula empréstimo
    const calculateLoan = (amount, installments) => {
        const monthlyRate = INTEREST_RATE;
        const totalAmount = amount * Math.pow(1 + monthlyRate, installments / 4); // Convertendo semanas para meses
        const installmentValue = totalAmount / installments;
        const totalInterest = totalAmount - amount;
        
        return {
            installmentValue: installmentValue,
            totalInterest: totalInterest,
            totalToPay: totalAmount
        };
    };

    // Atualiza o resumo do empréstimo
    const updateLoanSummary = () => {
        const amount = parseFloat(document.getElementById('loan-amount').value) || 0;
        const installments = parseInt(document.getElementById('loan-installments').value) || 4;
        
        if (amount > 0) {
            const loan = calculateLoan(amount, installments);
            
            document.getElementById('installment-value').textContent = formatMoney(loan.installmentValue);
            document.getElementById('total-interest').textContent = formatMoney(loan.totalInterest);
            document.getElementById('total-to-pay').textContent = formatMoney(loan.totalToPay);
        } else {
            document.getElementById('installment-value').textContent = formatMoney(0);
            document.getElementById('total-interest').textContent = formatMoney(0);
            document.getElementById('total-to-pay').textContent = formatMoney(0);
        }
    };

    // Navegação entre telas
    const showScreen = (screenName) => {
        // Remove classe active de todas as telas e botões
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Adiciona classe active na tela e botão selecionados
        document.getElementById(`${screenName}-screen`).classList.add('active');
        document.querySelector(`[data-screen="${screenName}"]`).classList.add('active');
        
        currentScreen = screenName;
    };

    // Atualiza dados do dashboard
    const updateDashboard = (data) => {
        if (data) {
            document.getElementById('user-name').textContent = data.name || 'N/A';
            document.getElementById('user-id').textContent = `ID: ${data.id || '--'}`;
            document.getElementById('balance-amount').textContent = formatMoney(data.balance);
            document.getElementById('last-update').textContent = 'Agora';
            
            // Atualiza informações de empréstimo se existirem
            if (data.activeLoan) {
                document.getElementById('active-loan-amount').textContent = formatMoney(data.activeLoan.remainingAmount);
                const progress = ((data.activeLoan.totalInstallments - data.activeLoan.remainingInstallments) / data.activeLoan.totalInstallments) * 100;
                document.getElementById('loan-progress-fill').style.width = `${progress}%`;
                document.getElementById('loan-progress-text').textContent = 
                    `${data.activeLoan.totalInstallments - data.activeLoan.remainingInstallments}/${data.activeLoan.totalInstallments} parcelas pagas`;
            } else {
                document.getElementById('active-loan-amount').textContent = formatMoney(0);
                document.getElementById('loan-progress-fill').style.width = '0%';
                document.getElementById('loan-progress-text').textContent = '0/0 parcelas pagas';
            }
            
            // Atualiza transações recentes
            updateRecentTransactions(data.recentTransactions || []);
        }
    };

    // Atualiza transações recentes
    const updateRecentTransactions = (transactions) => {
        const container = document.getElementById('recent-transactions-list');
        
        if (transactions.length === 0) {
            container.innerHTML = `
                <div class="no-transactions">
                    <i class="fas fa-inbox"></i>
                    <p>Nenhuma transação recente</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = transactions.slice(0, 5).map(transaction => `
            <div class="transaction-item">
                <div class="transaction-icon">
                    <i class="fas ${getTransactionIcon(transaction.type)}"></i>
                </div>
                <div class="transaction-details">
                    <div class="transaction-title">${transaction.description}</div>
                    <div class="transaction-date">${formatDate(transaction.date)}</div>
                </div>
                <div class="transaction-amount ${transaction.type === 'withdraw' || transaction.type === 'loan' ? 'negative' : 'positive'}">
                    ${transaction.type === 'withdraw' || transaction.type === 'loan' ? '-' : '+'}${formatMoney(transaction.amount)}
                </div>
            </div>
        `).join('');
    };

    // Retorna ícone baseado no tipo de transação
    const getTransactionIcon = (type) => {
        const icons = {
            'deposit': 'fa-plus-circle',
            'withdraw': 'fa-minus-circle',
            'transfer': 'fa-exchange-alt',
            'loan': 'fa-hand-holding-usd',
            'loan_payment': 'fa-credit-card'
        };
        return icons[type] || 'fa-circle';
    };

    // Mostra modal de confirmação
    const showModal = (title, message, onConfirm) => {
        document.getElementById('modal-title').textContent = title;
        document.getElementById('modal-message').textContent = message;
        modal.style.display = 'block';
        
        // Remove listeners anteriores
        const confirmBtn = document.getElementById('modal-confirm');
        const cancelBtn = document.getElementById('modal-cancel');
        const closeBtn = document.getElementById('modal-close');
        
        confirmBtn.onclick = () => {
            modal.style.display = 'none';
            if (onConfirm) onConfirm();
        };
        
        cancelBtn.onclick = () => {
            modal.style.display = 'none';
        };
        
        closeBtn.onclick = () => {
            modal.style.display = 'none';
        };
    };

    // Funções para abrir modais específicos
    window.openTransferModal = () => {
        document.getElementById('transfer-modal').style.display = 'block';
        document.getElementById('transfer-target-id').value = '';
        document.getElementById('transfer-amount').value = '';
    };

    window.openDepositModal = () => {
        document.getElementById('deposit-modal').style.display = 'block';
        document.getElementById('deposit-amount').value = '';
    };

    window.openWithdrawModal = () => {
        document.getElementById('withdraw-modal').style.display = 'block';
        document.getElementById('withdraw-amount').value = '';
    };

    // Funções para fechar modais
    window.closeModal = (modalId) => {
        document.getElementById(modalId).style.display = 'none';
    };

    // Funções para executar ações
    window.executeTransfer = () => {
        const targetId = parseInt(document.getElementById('transfer-target-id').value);
        const amount = parseFloat(document.getElementById('transfer-amount').value);
        
        if (!targetId || targetId <= 0) {
            showModal('Erro', 'Por favor, insira um ID válido.', null);
            return;
        }
        
        if (!amount || amount <= 0) {
            showModal('Erro', 'Por favor, insira um valor válido.', null);
            return;
        }
        
        if (amount > userData.balance) {
            showModal('Erro', 'Saldo insuficiente para realizar a transferência.', null);
            return;
        }

        post('transfer', { targetId, amount });
        closeModal('transfer-modal');
    };

    window.executeDeposit = () => {
        const amount = parseFloat(document.getElementById('deposit-amount').value);
        
        if (!amount || amount <= 0) {
            showModal('Erro', 'Por favor, insira um valor válido.', null);
            return;
        }

        post('deposit', { amount });
        closeModal('deposit-modal');
    };

    window.executeWithdraw = () => {
        const amount = parseFloat(document.getElementById('withdraw-amount').value);
        
        if (!amount || amount <= 0) {
            showModal('Erro', 'Por favor, insira um valor válido.', null);
            return;
        }

        if (amount > userData.balance) {
            showModal('Erro', 'Saldo insuficiente para realizar o saque.', null);
            return;
        }

        post('withdraw', { amount });
        closeModal('withdraw-modal');
    };

    // Event Listeners

    // Navegação
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const screen = btn.getAttribute('data-screen');
            showScreen(screen);
        });
    });

    // Cálculo automático de empréstimo
    document.getElementById('loan-amount').addEventListener('input', updateLoanSummary);
    document.getElementById('loan-installments').addEventListener('change', updateLoanSummary);

    // Solicitar empréstimo
    document.getElementById('request-loan-btn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('loan-amount').value);
        const installments = parseInt(document.getElementById('loan-installments').value);
        
        if (!amount || amount < 1000) {
            showModal('Erro', 'Por favor, insira um valor válido (mínimo R$ 1.000,00)', null);
            return;
        }
        
        const loan = calculateLoan(amount, installments);
        
        showModal(
            'Confirmar Empréstimo',
            `Deseja solicitar um empréstimo de ${formatMoney(amount)} em ${installments} parcelas de ${formatMoney(loan.installmentValue)}?`,
            () => {
                post('requestLoan', { amount, installments });
            }
        );
    });

    // Botões de ação rápida
    document.getElementById('transfer-btn').addEventListener('click', () => {
        openTransferModal();
    });

    document.getElementById('deposit-btn').addEventListener('click', () => {
        openDepositModal();
    });

    document.getElementById('withdraw-btn').addEventListener('click', () => {
        openWithdrawModal();
    });

    document.getElementById('loan-btn').addEventListener('click', () => {
        showScreen('loans');
    });

    // Fechar banco
    closeBtn.addEventListener('click', () => {
        post('close');
    });

    // ESC para fechar
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            // Fecha qualquer modal aberto
            const openModals = document.querySelectorAll('.modal[style*="block"]');
            if (openModals.length > 0) {
                openModals.forEach(modal => {
                    modal.style.display = 'none';
                });
            } else {
            post('close');
            }
        }
    });

    // Ouvinte para mensagens do client.lua
    window.addEventListener('message', function (event) {
        const item = event.data;

        if (item.action === "show") {
            bankMainScreen.style.display = item.state ? 'flex' : 'none';
        }

        if (item.action === "updateData") {
            userData = item.userData;
            updateDashboard(userData);
        }

        if (item.action === "showNotification") {
            showModal(item.title || 'Notificação', item.message, null);
        }
    });

    // Inicialização
    console.log('[EllGringo Bank] Interface carregada com sucesso!');
}); 