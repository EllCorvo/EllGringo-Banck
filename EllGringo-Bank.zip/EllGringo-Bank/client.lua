print('--- [EllGringo-Bank] O SCRIPT ESTÁ SENDO LIDO PELO FIVEM ---')

local display = false
local vRP = nil
local Proxy = module("vrp", "lib/Proxy")
local vehiclesBlocked = false

-- Carrega o vRP e registra o comando
CreateThread(function()
    vRP = Proxy.getInterface("vRP")
    if vRP then
        RegisterCommand('bank', function()
            -- Quando o comando é usado, alterna a exibição
            SetDisplay(not display) 
        end, false)
        print('[EllGringo-Bank] Banco pronto. Use /bank para abrir.')
    else
        print('[EllGringo-Bank] ERRO: vRP não encontrado.')
    end
end)

-- Função para controlar a NUI
function SetDisplay(bool)
    display = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({ action = "show", state = bool })

    -- Se estiver abrindo o banco, pede os dados ao servidor
    if bool then
        TriggerServerEvent('bank:getData')
    end
end

-- Recebe os dados do servidor e envia para a NUI
RegisterNetEvent('bank:receiveData')
AddEventHandler('bank:receiveData', function(userData)
    SendNUIMessage({
        action = "updateData",
        userData = userData
    })
end)

-- Evento para bloquear veículos
RegisterNetEvent('bank:blockVehicles')
AddEventHandler('bank:blockVehicles', function()
    vehiclesBlocked = true
    
    -- Notifica o jogador
    TriggerEvent('chat:addMessage', {
        args = {"🏦 BANCO", "⚠️ Seus veículos foram bloqueados devido a atraso no empréstimo. Pague suas parcelas para desbloquear."}
    })
    
    -- Toca som de alerta
    PlaySoundFrontend(-1, "CHECKPOINT_MISSED", "HUD_MINI_GAME_SOUNDSET", 1)
    
    print('[EllGringo-Bank] Veículos bloqueados para o jogador')
end)

-- Evento para desbloquear veículos
RegisterNetEvent('bank:unblockVehicles')
AddEventHandler('bank:unblockVehicles', function()
    vehiclesBlocked = false
    
    -- Notifica o jogador
    TriggerEvent('chat:addMessage', {
        args = {"🏦 BANCO", "✅ Seus veículos foram desbloqueados! Empréstimo em dia."}
    })
    
    print('[EllGringo-Bank] Veículos desbloqueados para o jogador')
end)

-- Thread para verificar se pode usar veículos
CreateThread(function()
    while true do
        Wait(1000)
        
        if vehiclesBlocked then
            local ped = PlayerPedId()
            if IsPedInAnyVehicle(ped, false) then
                local vehicle = GetVehiclePedIsIn(ped, false)
                if vehicle ~= 0 then
                    -- Impede o jogador de dirigir
                    SetVehicleEngineOn(vehicle, false, true, true)
                    
                    -- Mostra mensagem de bloqueio
                    DrawText3D(GetEntityCoords(vehicle), "🚫 Veículo bloqueado - Empréstimo em atraso")
                end
            end
        end
    end
end)

-- Função para desenhar texto 3D
function DrawText3D(coords, text)
    local onScreen, _x, _y = World3dToScreen2d(coords.x, coords.y, coords.z + 1.0)
    local px, py, pz = table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 41, 11, 41, 68)
end

-- Callbacks da NUI
RegisterNUICallback('close', function(data, cb)
    SetDisplay(false)
    cb('ok')
end)

RegisterNUICallback('requestLoan', function(data, cb)
    TriggerServerEvent('bank:requestLoan', data.amount, data.installments)
    cb('ok')
end)

RegisterNUICallback('transfer', function(data, cb)
    TriggerServerEvent('bank:transfer', data.targetId, data.amount)
    cb('ok')
end)

RegisterNUICallback('deposit', function(data, cb)
    TriggerServerEvent('bank:deposit', data.amount)
    cb('ok')
end)

RegisterNUICallback('withdraw', function(data, cb)
    TriggerServerEvent('bank:withdraw', data.amount)
    cb('ok')
end)

-- Eventos de resposta do servidor
RegisterNetEvent('bank:loanResponse')
AddEventHandler('bank:loanResponse', function(success, message)
    SendNUIMessage({
        action = "showNotification",
        title = success and "Empréstimo Aprovado" or "Erro no Empréstimo",
        message = message
    })
    
    if success then
        -- Atualiza os dados após empréstimo aprovado
        Wait(1000)
        TriggerServerEvent('bank:getData')
    end
end)

RegisterNetEvent('bank:transactionResponse')
AddEventHandler('bank:transactionResponse', function(success, message)
    SendNUIMessage({
        action = "showNotification",
        title = success and "Transação Realizada" or "Erro na Transação",
        message = message
    })
    
    if success then
        -- Atualiza os dados após transação
        Wait(1000)
        TriggerServerEvent('bank:getData')
    end
end)

-- Segurança extra para fechar com ESC e ao morrer
CreateThread(function()
    while true do
        Wait(0)
        if display and IsControlJustReleased(0, 322) then -- ESC
            SetDisplay(false)
        end
    end
end)

AddEventHandler('playerSpawned', function()
    if display then
        SetDisplay(false)
    end
end)print('[EllGringo-Bank] Leitura final do script do cliente concluída.') 

