local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","vrp_user_ids")

LOAN_CONFIG = {
    MIN_AMOUNT = 500,
    MAX_AMOUNT = 50000,
    INTEREST_RATE = 0.05,
    MAX_ACTIVE_LOANS = 1,
    VEHICLE_BLOCK_DAYS = 7
}

function initializeDatabase()
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS `vrp_bank_loans` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `user_id` INT(11) NOT NULL,
            `amount` INT(11) NOT NULL,
            `total_amount` INT(11) NOT NULL,
            `installment_value` INT(11) NOT NULL,
            `total_installments` INT(11) NOT NULL DEFAULT 4,
            `paid_installments` INT(11) NOT NULL DEFAULT 0,
            `remaining_amount` INT(11) NOT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'active',
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `last_payment_date` TIMESTAMP NULL DEFAULT NULL,
            `next_payment_date` TIMESTAMP NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            INDEX `user_id` (`user_id`)
        );
    ]])
    
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS `vrp_bank_transactions` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `user_id` INT(11) NOT NULL,
            `type` VARCHAR(50) NOT NULL,
            `amount` INT(11) NOT NULL,
            `description` VARCHAR(255) NULL,
            `related_user_id` INT(11) NULL DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        );
    ]])
    print('[EllGringo-Bank] Tabelas do banco de dados verificadas/criadas com sucesso.')
end

function calculateLoan(amount, installments)
    local totalAmount = amount * (1 + (LOAN_CONFIG.INTEREST_RATE * (installments / 4)))
    local installmentValue = totalAmount / installments
    return {
        totalAmount = totalAmount,
        installmentValue = installmentValue
    }
end

RegisterNetEvent('bank:getData', function()
    local source = source
    local user_id = vRP.getUserId(source)
    
    if user_id then
        local identity = vRP.getUserIdentity(user_id)
        local balance = vRP.getBankMoney(user_id)
        
        if identity then
            MySQL.Async.fetchAll('SELECT * FROM vrp_bank_loans WHERE user_id = @user_id AND status = "active" LIMIT 1', {
                ['@user_id'] = user_id
            }, function(loans)
                local activeLoan = nil
                if loans and #loans > 0 then
                    activeLoan = {
                        remainingAmount = loans[1].remaining_amount,
                        totalInstallments = loans[1].total_installments,
                        remainingInstallments = loans[1].total_installments - loans[1].paid_installments
                    }
                end

                MySQL.Async.fetchAll([[
                    SELECT * FROM vrp_bank_transactions 
                    WHERE user_id = @user_id 
                    ORDER BY created_at DESC 
                    LIMIT 10
                ]], {
                    ['@user_id'] = user_id
                }, function(transactions)
                    local recentTransactions = {}
                    if transactions then
                        for _, transaction in ipairs(transactions) do
                            table.insert(recentTransactions, {
                                id = transaction.id,
                                type = transaction.type,
                                amount = transaction.amount,
                                description = transaction.description,
                                date = transaction.created_at,
                                relatedUserId = transaction.related_user_id
                            })
                        end
                    end
                    
                    local userData = {
                        id = user_id,
                        name = identity.firstname .. ' ' .. identity.name,
                        balance = balance,
                        activeLoan = activeLoan,
                        recentTransactions = recentTransactions
                    }
                    
                    TriggerClientEvent('bank:receiveData', source, userData)
                end)
            end)
        end
    end
end)

RegisterNetEvent('bank:requestLoan', function(amount, installments)
    local source = source
    local user_id = vRP.getUserId(source)
    
    if not user_id then
        TriggerClientEvent('bank:loanResponse', source, false, "Usuário não encontrado.")
        return
    end
    
    if amount < LOAN_CONFIG.MIN_AMOUNT or amount > LOAN_CONFIG.MAX_AMOUNT then
        TriggerClientEvent('bank:loanResponse', source, false, string.format("Valor deve estar entre R$ %s e R$ %s.", 
            formatMoney(LOAN_CONFIG.MIN_AMOUNT), formatMoney(LOAN_CONFIG.MAX_AMOUNT)))
        return
    end
    
    if installments < 4 or installments > 20 then
        TriggerClientEvent('bank:loanResponse', source, false, "Número de parcelas deve estar entre 4 e 20.")
        return
    end
    
    MySQL.Async.fetchAll('SELECT COUNT(*) as count FROM vrp_bank_loans WHERE user_id = @user_id AND status = "active"', {
        ['@user_id'] = user_id
    }, function(result)
        if result[1].count >= LOAN_CONFIG.MAX_ACTIVE_LOANS then
            TriggerClientEvent('bank:loanResponse', source, false, "Você já possui um empréstimo ativo.")
            return
        end
        
        local loan = calculateLoan(amount, installments)
        
        MySQL.Async.execute([[
            INSERT INTO vrp_bank_loans 
            (user_id, amount, total_amount, installment_value, total_installments, remaining_amount, next_payment_date)
            VALUES (@user_id, @amount, @total_amount, @installment_value, @total_installments, @total_amount, DATE_ADD(NOW(), INTERVAL 7 DAY))
        ]], {
            ['@user_id'] = user_id,
            ['@amount'] = amount,
            ['@total_amount'] = loan.totalAmount,
            ['@installment_value'] = loan.installmentValue,
            ['@total_installments'] = installments,
            ['@total_amount'] = loan.totalAmount
        }, function(rowsChanged)
            if rowsChanged and rowsChanged > 0 then
                vRP.setBankMoney(user_id, vRP.getBankMoney(user_id) + amount)
                
                MySQL.Async.execute([[
                    INSERT INTO vrp_bank_transactions (user_id, type, amount, description)
                    VALUES (@user_id, 'loan', @amount, 'Empréstimo aprovado')
                ]], {
                    ['@user_id'] = user_id,
                    ['@amount'] = amount
                })
                
                TriggerClientEvent('bank:loanResponse', source, true, 
                    string.format("Empréstimo de R$ %s aprovado! Primeira parcela vence em 7 dias.", formatMoney(amount)))
            else
                TriggerClientEvent('bank:loanResponse', source, false, "Erro ao processar empréstimo.")
            end
        end)
    end)
end)

RegisterNetEvent('bank:transfer', function(targetId, amount)
    local source = source
    local user_id = vRP.getUserId(source)
    
    if not user_id then
        TriggerClientEvent('bank:transactionResponse', source, false, "Usuário não encontrado.")
        return
    end
    
    if not targetId or amount <= 0 then
        TriggerClientEvent('bank:transactionResponse', source, false, "Dados inválidos para transferência.")
        return
    end
    
    local balance = vRP.getBankMoney(user_id)
    if balance < amount then
        TriggerClientEvent('bank:transactionResponse', source, false, "Saldo insuficiente para transferência.")
        return
    end
    
    vRP.setBankMoney(user_id, balance - amount)
    vRP.setBankMoney(targetId, vRP.getBankMoney(targetId) + amount)
    
    MySQL.Async.execute([[
        INSERT INTO vrp_bank_transactions (user_id, type, amount, description, related_user_id)
        VALUES (@user_id, 'transfer', @amount, 'Transferência enviada', @target_id)
    ]], {
        ['@user_id'] = user_id,
        ['@amount'] = amount,
        ['@target_id'] = targetId
    })
    
    MySQL.Async.execute([[
        INSERT INTO vrp_bank_transactions (user_id, type, amount, description, related_user_id)
        VALUES (@target_id, 'transfer', @amount, 'Transferência recebida', @source_id)
    ]], {
        ['@user_id'] = targetId,
        ['@amount'] = amount,
        ['@source_id'] = user_id
    })
    
    TriggerClientEvent('bank:transactionResponse', source, true, 
        string.format("Transferência de R$ %s realizada com sucesso!", formatMoney(amount)))
end)

RegisterNetEvent('bank:deposit', function(amount)
    local source = source
    local user_id = vRP.getUserId(source)
    
    if not user_id or amount <= 0 then
        TriggerClientEvent('bank:transactionResponse', source, false, "Dados inválidos para depósito.")
        return
    end
    
    local money = vRP.getMoney(user_id)
    if money < amount then
        TriggerClientEvent('bank:transactionResponse', source, false, "Dinheiro insuficiente para depósito.")
        return
    end
    
    vRP.setMoney(user_id, money - amount)
    vRP.setBankMoney(user_id, vRP.getBankMoney(user_id) + amount)
    
    MySQL.Async.execute([[
        INSERT INTO vrp_bank_transactions 
        (user_id, type, amount, description)
        VALUES (@user_id, 'deposit', @amount, 'Depósito realizado')
    ]], {
        ['@user_id'] = user_id,
        ['@amount'] = amount
    })
    
    TriggerClientEvent('bank:transactionResponse', source, true, 
        string.format("Depósito de R$ %s realizado com sucesso!", formatMoney(amount)))
end)

RegisterNetEvent('bank:withdraw', function(amount)
    local source = source
    local user_id = vRP.getUserId(source)
    
    if not user_id or amount <= 0 then
        TriggerClientEvent('bank:transactionResponse', source, false, "Dados inválidos para saque.")
        return
    end
    
    local balance = vRP.getBankMoney(user_id)
    if balance < amount then
        TriggerClientEvent('bank:transactionResponse', source, false, "Saldo insuficiente para saque.")
        return
    end
    
    vRP.setBankMoney(user_id, balance - amount)
    vRP.setMoney(user_id, vRP.getMoney(user_id) + amount)
    
    MySQL.Async.execute([[
        INSERT INTO vrp_bank_transactions 
        (user_id, type, amount, description)
        VALUES (@user_id, 'withdraw', @amount, 'Saque realizado')
    ]], {
        ['@user_id'] = user_id,
        ['@amount'] = amount
    })
    
    TriggerClientEvent('bank:transactionResponse', source, true, 
        string.format("Saque de R$ %s realizado com sucesso!", formatMoney(amount)))
end)

RegisterNetEvent('bank:getActiveLoans', function()
    local source = source
    local user_id = vRP.getUserId(source)
    
    if not user_id then return end
    
    MySQL.Async.fetchAll('SELECT * FROM vrp_bank_loans WHERE user_id = @user_id AND status = "active"', {
        ['@user_id'] = user_id
    }, function(loans)
        TriggerClientEvent('bank:receiveActiveLoans', source, loans or {})
    end)
end)

RegisterNetEvent('bank:payLoanInstallment', function(loanId)
    local source = source
    local user_id = vRP.getUserId(source)
    
    if not user_id or not loanId then return end
    
    MySQL.Async.fetchAll('SELECT * FROM vrp_bank_loans WHERE id = @id AND user_id = @user_id AND status = "active"', {
        ['@id'] = loanId,
        ['@user_id'] = user_id
    }, function(loans)
        if not loans or #loans == 0 then
            TriggerClientEvent('bank:transactionResponse', source, false, "Empréstimo não encontrado ou já quitado.")
            return
        end
        
        local loan = loans[1]
        local balance = vRP.getBankMoney(user_id)
        
        if balance < loan.installment_value then
            TriggerClientEvent('bank:transactionResponse', source, false, "Saldo insuficiente para pagar a parcela.")
            return
        end
        
        vRP.setBankMoney(user_id, balance - loan.installment_value)
        
        local newPaidInstallments = loan.paid_installments + 1
        local newRemainingAmount = loan.remaining_amount - loan.installment_value
        local status = newPaidInstallments >= loan.total_installments and 'paid' or 'active'
        
        MySQL.Async.execute([[
            UPDATE vrp_bank_loans 
            SET paid_installments = @paid_installments, remaining_amount = @remaining_amount, status = @status
            WHERE id = @loan_id
        ]], {
            ['@paid_installments'] = newPaidInstallments,
            ['@remaining_amount'] = newRemainingAmount,
            ['@status'] = status,
            ['@loan_id'] = loan.id
        })
        
        MySQL.Async.execute([[
            INSERT INTO vrp_bank_transactions (user_id, type, amount, description, related_user_id)
            VALUES (@user_id, 'loan_payment', @amount, 'Pagamento de Parcela', @loan_id)
        ]], {
            ['@user_id'] = user_id,
            ['@amount'] = loan.installment_value,
            ['@loan_id'] = loan.id
        })
        
        local message = status == 'paid' 
            and "Empréstimo quitado com sucesso!" 
            or string.format("Parcela paga! Restam %d parcelas.", loan.total_installments - newPaidInstallments)
            
        TriggerClientEvent('bank:transactionResponse', source, true, message)
    end)
end)

RegisterNetEvent('bank:payOffLoan', function(loanId)
    local source = source
    local user_id = vRP.getUserId(source)
    
    if not user_id or not loanId then return end
    
    MySQL.Async.fetchAll('SELECT * FROM vrp_bank_loans WHERE id = @id AND user_id = @user_id AND status = "active"', {
        ['@id'] = loanId,
        ['@user_id'] = user_id
    }, function(loans)
        if not loans or #loans == 0 then
            TriggerClientEvent('bank:transactionResponse', source, false, "Empréstimo não encontrado ou já quitado.")
            return
        end
        
        local loan = loans[1]
        local balance = vRP.getBankMoney(user_id)
        
        if balance < loan.remaining_amount then
            TriggerClientEvent('bank:transactionResponse', source, false, "Saldo insuficiente para quitar o empréstimo.")
            return
        end
        
        vRP.setBankMoney(user_id, balance - loan.remaining_amount)
        
        MySQL.Async.execute("UPDATE vrp_bank_loans SET status = 'paid', remaining_amount = 0, paid_installments = total_installments WHERE id = @id", {
            ['@id'] = loan.id
        })
        
        MySQL.Async.execute([[
            INSERT INTO vrp_bank_transactions (user_id, type, amount, description, related_user_id)
            VALUES (@user_id, 'loan_payment', @amount, 'Quitação de Empréstimo', @loan_id)
        ]], {
            ['@user_id'] = user_id,
            ['@amount'] = loan.remaining_amount,
            ['@loan_id'] = loan.id
        })
        
        TriggerClientEvent('bank:transactionResponse', source, true, "Empréstimo quitado com sucesso!")
    end)
end)

function formatMoney(amount)
    return string.format("%.2f", amount or 0)
end

CreateThread(function()
    Wait(2000) 
    initializeDatabase()
    print('[EllGringo-Bank] Script do servidor carregado com sucesso!')
end)

CreateThread(function()
    while true do
        Wait(3600000)
        
        MySQL.Async.fetchAll([[
            SELECT user_id FROM vrp_bank_loans 
            WHERE status = 'active' 
            AND next_payment_date < DATE_SUB(NOW(), INTERVAL @days DAY)
        ]], {
            ['@days'] = LOAN_CONFIG.VEHICLE_BLOCK_DAYS
        }, function(result)
            if result then
                for _, row in ipairs(result) do
                    local source = vRP.getUserSource(row.user_id)
                    if source then
                        TriggerClientEvent('bank:blockVehicles', source)
                    end
                end
            end
        end)
    end
end)
