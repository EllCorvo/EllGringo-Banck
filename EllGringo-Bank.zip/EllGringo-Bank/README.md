# 🏦 EllGringo Bank - Sistema Bancário Profissional

Um sistema bancário completo e profissional para FiveM com interface moderna, sistema de empréstimos e controle de veículos.

## ✨ Características

### 🎨 Interface Profissional
- Design moderno e responsivo
- Múltiplas telas (Dashboard, Empréstimos, Histórico, Configurações)
- Animações suaves e efeitos visuais
- Emojis e ícones para melhor experiência
- Tema claro e profissional

### 💰 Sistema de Empréstimos
- Solicitação de empréstimos com parcelamento
- Cálculo automático de juros (5% ao mês)
- Parcelas semanais (4 a 20 semanas)
- Controle de atrasos e bloqueio de veículos
- Histórico completo de transações

### 🚗 Sistema de Bloqueio de Veículos
- Bloqueio automático após 7 dias de atraso
- Impede o jogador de dirigir veículos
- Notificações visuais e sonoras
- Desbloqueio automático após pagamento

### 📊 Dashboard Completo
- Saldo em tempo real
- Status de empréstimos ativos
- Progresso de pagamento
- Transações recentes
- Ações rápidas

## 🚀 Instalação

1. **Copie a pasta** `EllGringo-Bank` para `resources/[Core]/`
2. **Adicione** ao seu `server.cfg`:
   ```
   ensure EllGringo-Bank
   ```
3. **Reinicie** o servidor

## 📋 Comandos

- `/bank` - Abre o painel bancário

## 🗄️ Estrutura do Banco de Dados

O sistema cria automaticamente duas tabelas:

### `vrp_bank_loans`
- Controle de empréstimos ativos
- Parcelas pagas e restantes
- Datas de vencimento
- Status do empréstimo

### `vrp_bank_transactions`
- Histórico completo de transações
- Tipos: depósito, saque, transferência, empréstimo, pagamento
- Relacionamento entre usuários

## ⚙️ Configurações

No arquivo `server.lua`, você pode ajustar:

```lua
local LOAN_CONFIG = {
    MIN_AMOUNT = 1000,        -- Valor mínimo do empréstimo
    MAX_AMOUNT = 100000,      -- Valor máximo do empréstimo
    INTEREST_RATE = 0.05,     -- Taxa de juros (5% ao mês)
    MAX_ACTIVE_LOANS = 1,     -- Máximo de empréstimos ativos por jogador
    VEHICLE_BLOCK_DAYS = 7    -- Dias de atraso para bloquear veículos
}
```

## 🎯 Funcionalidades

### Dashboard
- **Saldo Disponível**: Mostra o saldo atual da conta
- **Empréstimos Ativos**: Status e progresso de pagamento
- **Ações Rápidas**: Transferir, Depositar, Sacar, Solicitar Empréstimo
- **Transações Recentes**: Últimas 5 transações

### Empréstimos
- **Empréstimos Ativos**: Lista de empréstimos em andamento
- **Solicitar Novo**: Formulário com cálculo automático
- **Resumo**: Valor da parcela, juros totais, total a pagar

### Histórico
- **Filtros**: Por tipo de transação
- **Detalhes**: Data, valor, descrição
- **Paginação**: Visualização organizada

### Configurações
- **Notificações**: Controle de alertas
- **Segurança**: Configurações de bloqueio

## 🔧 Integração com vRP

O sistema é totalmente integrado com o vRP:
- Usa `vRP.getBankMoney()` e `vRP.setBankMoney()`
- Identidade do jogador via `vRP.getUserIdentity()`
- Sistema de IDs do vRP

## 🎨 Personalização

### Cores
As cores podem ser alteradas no arquivo `style.css`:
```css
:root {
    --primary-color: #1e3a8a;    /* Azul principal */
    --secondary-color: #f59e0b;  /* Dourado */
    --success-color: #10b981;    /* Verde */
    --warning-color: #f59e0b;    /* Amarelo */
    --danger-color: #ef4444;     /* Vermelho */
}
```

### Emojis e Ícones
Todos os emojis e ícones podem ser personalizados no HTML e JavaScript.

## 🐛 Solução de Problemas

### Erro "Proxy is nil"
- Certifique-se de que o vRP está carregado antes do banco
- Verifique se o `ensure vrp` está antes do `ensure EllGringo-Bank`

### Tabelas não criadas
- Verifique se o MySQL está funcionando
- Confirme as permissões do banco de dados

### Interface não abre
- Verifique se todos os arquivos estão na pasta correta
- Confirme se o comando `/bank` está registrado

## 📝 Changelog

### v1.0.0
- ✅ Sistema bancário completo
- ✅ Interface profissional
- ✅ Sistema de empréstimos
- ✅ Bloqueio de veículos
- ✅ Histórico de transações
- ✅ Dashboard responsivo

## 🤝 Suporte

Para suporte ou dúvidas:
- Abra uma issue no repositório
- Entre em contato com a equipe de desenvolvimento

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

---

**Desenvolvido com ❤️ pela equipe EllGringo** 