fx_version 'cerulean'
game 'gta5'

author 'EllGringo'
description 'Sistema de Banco para vRP'
version '1.0.0'

shared_script '@vrp/lib/utils.lua'

client_script 'client.lua'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/script.js',
    'ui/assets/*'
}

dependencies {
    'vrp',
    'oxmysql'
}

lua54 'yes' 